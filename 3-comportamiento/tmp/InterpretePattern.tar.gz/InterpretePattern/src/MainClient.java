/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class MainClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Context context = new Context();
		context.put("x", 7);
		context.put("y", 2);
		Evaluator evaluator = new Evaluator(context, "x 3 + 4 - y * 3 /");
		System.out.println(evaluator.evaluate()); // should print 4

	}

}
