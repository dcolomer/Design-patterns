/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public interface Expression {

    int interpret(Context context);
}
