/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class Number implements Expression {

    private int value;

    public Number(int value) {
        this.value = value;
    }
    
    public int interpret(Context context) {
        return value;
    }
        
}
