/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class Multiply extends CompositeExpression {

    public Multiply(Expression left, Expression right) {
        super(left, right);
    }

    public int interpret(Context context) {
        return left.interpret(context) * right.interpret(context);
    }

}
