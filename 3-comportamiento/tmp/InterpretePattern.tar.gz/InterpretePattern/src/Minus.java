/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class Minus extends CompositeExpression {

    public Minus(Expression left, Expression right) {
        super(left, right);
    }

    public int interpret(Context context) {
        return left.interpret(context) - right.interpret(context);
    }

}
