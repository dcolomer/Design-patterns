/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public abstract class CompositeExpression implements Expression {

    protected Expression left;
    protected Expression right;

    public CompositeExpression(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

}
