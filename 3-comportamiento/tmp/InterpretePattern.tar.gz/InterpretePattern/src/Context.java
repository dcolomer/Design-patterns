import java.util.HashMap;
import java.util.Map;

/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class Context {

    private Map<String, Integer> map = new HashMap<String, Integer>();

    public void put(String variable, Integer value) {
        map.put(variable, value);
    }

    public Integer get(String variable) {
        return map.get(variable);
    }
}
