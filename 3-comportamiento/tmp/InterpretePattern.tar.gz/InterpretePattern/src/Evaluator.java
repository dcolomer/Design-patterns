import java.util.Stack;

/**
 * 
 */

/**
 * @author dcolomer
 *
 */
public class Evaluator {

    private Context context;
    private String expression;

    public Evaluator(Context context, String expression) {
        this.context = context;
        this.expression = expression;
    }

    public int evaluate() {
        Stack<Expression> expressionStack = new Stack<Expression>();
        for (String token : expression.split(" ")) {
            if (token.trim().equals(""))
                continue;
            if (token.equals("+")) {
                Expression right = expressionStack.pop();
                Expression left = expressionStack.pop();
                expressionStack.push(new Plus(left, right));
            } else if (token.equals("-")) {
                Expression right = expressionStack.pop();
                Expression left = expressionStack.pop();
                expressionStack.push(new Minus(left, right));
            } else if (token.equals("*")) {
                Expression right = expressionStack.pop();
                Expression left = expressionStack.pop();
                expressionStack.push(new Multiply(left, right));
            } else if (token.equals("/")) {
                Expression right = expressionStack.pop();
                Expression left = expressionStack.pop();
                expressionStack.push(new Divide(left, right));
            } else if (Character.isLetter(token.charAt(0))) {
                expressionStack.push(new Variable(token));
            } else
                expressionStack.push(new Number(Integer.parseInt(token)));
        }
        if (expressionStack.isEmpty())
            return 0;
        Expression root = expressionStack.pop();
        return root.interpret(context);
    }

}
